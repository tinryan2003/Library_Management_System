package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.table.DefaultTableModel;

public class RC_SQL {
    DefaultTableModel model;
    //to set the book details into the table
    public void setIssueBookDetailsToTable(rojeru_san.complementos.RSTableMetro tbl_issueBookDetails) {
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from issue_book_details");

            while (rs.next()) {
                String id = rs.getString("id");
                String bookName = rs.getString("book_name");
                String StudentName = rs.getString("student_name");
                String issueDate = rs.getString("issue_date");
                String dueDate = rs.getString("due_date");
                String status = rs.getString("status");

                Object[] obj = {id, bookName, StudentName, issueDate, dueDate, status};
                model = (DefaultTableModel) tbl_issueBookDetails.getModel();
                model.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
    //method to clear table
    public void clearTable(rojeru_san.complementos.RSTableMetro tbl_issueBookDetails) {
        DefaultTableModel model = (DefaultTableModel) tbl_issueBookDetails.getModel();
        model.setRowCount(0);
    }
    
    //to fetch the record using date fields
    public boolean search(java.sql.Date uFromDate, java.sql.Date uToDate,rojeru_san.complementos.RSTableMetro tbl_issueBookDetails) {
        long l1 = uFromDate.getTime();
        long l2 = uToDate.getTime();

        java.sql.Date fromDate = new java.sql.Date(l1);
        java.sql.Date toDate = new java.sql.Date(l2);
        try {
            Connection con = DBConnection.getConnection();
            String sql = "select * from issue_book_details where issue_date between ? and ?;";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setDate(1, fromDate);
            pst.setDate(2, toDate);
            ResultSet rs = pst.executeQuery();
            boolean flag = true;
            while (rs.next()) {
                flag = false;
                String issueId = rs.getString("id");
                String bookName = rs.getString("book_name");
                String studentName = rs.getString("student_name");
                String issueDate = rs.getString("issue_date");
                String dueDate = rs.getString("due_date");
                String status = rs.getString("status");
                Object[] obj = {issueId, bookName, studentName, issueDate, dueDate, status};
                model = (DefaultTableModel) tbl_issueBookDetails.getModel();
                model.addRow(obj);
            }
                return flag;                
            }catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    
}

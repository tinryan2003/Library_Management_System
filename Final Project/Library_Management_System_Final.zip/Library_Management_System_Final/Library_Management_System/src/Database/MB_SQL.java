
package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

public class MB_SQL {
    DefaultTableModel model;  

    public void setBookDetailsToTable(rojeru_san.complementos.RSTableMetro tbl_bookDetails){
        
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from book_details");
            
            while(rs.next()){
                int bookId = rs.getInt("book_id");
                String bookName = rs.getString("book_name");
                String author = rs.getString("author");
                int quantity = rs.getInt("quantity");
                
                Object[] obj = {bookId,bookName,author,quantity};
                model =(DefaultTableModel) tbl_bookDetails.getModel();
                model.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    public boolean addBooksql(Controller.Book b) {
    boolean isAdded = false;        
    try {
        Connection con = DBConnection.getConnection();
        String sql = "INSERT INTO book_details (book_id, book_name, author, quantity) VALUES (?, ?, ?, ?)";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setInt(1, b.bookId);
        pst.setString(2, b.bookName);
        pst.setString(3, b.author);
        pst.setInt(4, b.quantity);

        int rowCount = pst.executeUpdate();
        if (rowCount > 0) {
            isAdded = true;
        } else {
            isAdded = false;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return isAdded;
}
    
    //to update book details
    public boolean updateBooksql(Controller.Book b){
      boolean isUpdated = false;
        try {
            Connection con = DBConnection.getConnection();
            String sql = "update book_details set book_name = ?,author = ?,quantity = ? where book_id = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(4, b.bookId);
            pst.setString(1, b.bookName);
            pst.setString(2, b.author);
            pst.setInt(3, b.quantity);
            
            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                isUpdated = true;
            }else{
                isUpdated = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return isUpdated;
    }
    
    //method to delete book detail
    public boolean deleteBooksql(int bookId){
        boolean isDeleted = false;        
        try {
            Connection con = DBConnection.getConnection();
            String sql = "delete from book_details where book_id = ? ";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bookId);
            
            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                isDeleted = true;
            }else{
                isDeleted = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return isDeleted;
    }
    
    //method to clear table
    
    public void clearTable(rojeru_san.complementos.RSTableMetro tbl_bookDetails){
        model = (DefaultTableModel) tbl_bookDetails.getModel();
        model.setRowCount(0);
    }
    
}


package Database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import java.sql.Statement;

public class IBD_SQL {
    DefaultTableModel model;
    
    //to set the book details into the table
    public void setIssueBookDetailsToDefaulterTable(rojeru_san.complementos.RSTableMetro tbl_DefaulterDetails) {
        long l = System.currentTimeMillis();
        Date todaysDate = new Date(l);

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from issue_book_details where due_date < ? and status = ? ");
            pst.setDate(1, todaysDate);
            pst.setString(2, "pending");
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String id = rs.getString("id");
                String bookName = rs.getString("book_name");
                String StudentName = rs.getString("student_name");
                Date issueDate = rs.getDate("issue_date");
                Date dueDate = rs.getDate("due_date");
                String status = rs.getString("status");
                            
                Object[] obj = {id, bookName, StudentName, issueDate, dueDate, status};
                model = (DefaultTableModel) tbl_DefaulterDetails.getModel();
                model.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
    public Controller.IBDetails getIssueBookDetailssql(int bookId, int studentId){
    Controller.IBDetails IssuebookDetails = null;
    try {
            Connection con = DBConnection.getConnection();
            String sql = "select * from issue_book_details where book_id = ? and student_id = ? and status = ?";

            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bookId);
            pst.setInt(2, studentId);
            pst.setString(3, "pending");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                int issueId = rs.getInt("id");
                String bookName = rs.getString("book_name");
                String studentName = rs.getString("student_name");
                java.util.Date issueDate = rs.getDate("issue_date");
                java.util.Date dueDate = rs.getDate("due_date");
                boolean bookError = false;
                IssuebookDetails = new Controller.IBDetails(issueId, bookName, studentName, issueDate,dueDate);
            }
            else{
                boolean bookError = true;
            }
            
        }catch (Exception e) {
            e.printStackTrace();
    }
    return IssuebookDetails;
}
    
    public void clearTable(rojeru_san.complementos.RSTableMetro tbl_studentDetails){
        model = (DefaultTableModel) tbl_studentDetails.getModel();
        model.setRowCount(0);
    }
    public void setIssueBookDetailsToTable(rojeru_san.complementos.RSTableMetro tbl_issueBookDetails) {

        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from issue_book_details where status = '" + "pending" + "'");

            while (rs.next()) {
                String id = rs.getString("id");
                String bookName = rs.getString("book_name");
                String StudentName = rs.getString("student_name");
                String issueDate = rs.getString("issue_date");
                String dueDate = rs.getString("due_date");
                String status = rs.getString("status");

                Object[] obj = {id, bookName, StudentName, issueDate, dueDate, status};
                model = (DefaultTableModel) tbl_issueBookDetails.getModel();
                model.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
}

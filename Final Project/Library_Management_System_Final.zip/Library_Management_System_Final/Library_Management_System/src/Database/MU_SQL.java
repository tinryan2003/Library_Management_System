package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MU_SQL {

    // method to insert values into users table
    public int insertSignupDetailssql(String username, String pwd, String email, String contact) {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "INSERT INTO users (name, password, email, contact) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, username);
            pst.setString(2, pwd);
            pst.setString(3, email);
            pst.setString(4, contact);

            int updatedRowCount = pst.executeUpdate();

            return updatedRowCount;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // check duplicate users
    public boolean checkDuplicateUser(String username) {
        boolean isExist = false;

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("SELECT * FROM users WHERE name = ?");
            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                isExist = true;
            } else {
                isExist = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isExist;
    }

}

package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

public class IB_SQL {
    public Controller.BookIssue getBookDetailssql(int bookId) {
        Controller.BookIssue bookDetails = null;

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from book_details where book_id = ?");
            pst.setInt(1, bookId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("book_id");
                String name = rs.getString("book_name");
                String author = rs.getString("author");
                int quantity = rs.getInt("quantity");

                bookDetails = new Controller.BookIssue(name, author, id, quantity);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return bookDetails;
    }
    
    public Controller.BookIssue getStudentDetailssql(int studentId) {
        Controller.BookIssue studentDetails = null;

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from student_details where student_id = ?");
            pst.setInt(1, studentId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("student_id");
                String name = rs.getString("name");
                String course = rs.getString("course");
                String branch = rs.getString("branch");

                studentDetails = new Controller.BookIssue(id, name, course, branch);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return studentDetails;
    }
    
    //checking whether book already allocated or not
    public boolean isAlreadyIssuedsql(int bookId, int studentId) {

        boolean isAlreadyIssued = false;

        try {
            Connection con = Database.DBConnection.getConnection();
            String sql = "select * from issue_book_details where book_id = ? and student_id = ? and status = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bookId);
            pst.setInt(2, studentId);
            pst.setString(3, "pending");

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                isAlreadyIssued = true;
            } else {
                isAlreadyIssued = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isAlreadyIssued;

    }
    
    //insert issue book details to database
    public boolean issueBooksql(int bookId, int studentId, String bookName, String studentName, Date uIssueDate, Date uDueDate, Long l1, long l2) {
        boolean isIssued = false;
        java.sql.Date sIssueDate = new java.sql.Date(l1);
        java.sql.Date sDueDate = new java.sql.Date(l2);
        try {
            Connection con = Database.DBConnection.getConnection();
            String sql = "insert into issue_book_details(book_id,book_name,student_id,student_name,"
                    + "issue_date,due_date,status) values(?,?,?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bookId);
            pst.setString(2, bookName);
            pst.setInt(3, studentId);
            pst.setString(4, studentName);
            pst.setDate(5, sIssueDate);
            pst.setDate(6, sDueDate);
            pst.setString(7, "pending");

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                isIssued = true;
            } else {
                isIssued = false;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return isIssued;

    }
    
    //updating book count
    public int updateBookCountsql(int bookId) {
        try {
            Connection con = Database.DBConnection.getConnection();
            String sql = "update book_details set quantity = quantity - 1 where book_id = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bookId);

            int rowCount = pst.executeUpdate();
            return rowCount;

        } catch (Exception e) {
            e.printStackTrace();
        }
            return 0;
}
}
    
    


package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class RB_SQL {
    public boolean returnBooksql(int studentId, int bookId){
        boolean isReturned = false;
        try {
                Connection con = Database.DBConnection.getConnection();
                String sql = "update issue_book_details set status = ? where student_id = ? and book_id = ? and status = ?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, "returned");
                pst.setInt(2, studentId);
                pst.setInt(3, bookId);
                pst.setString(4, "pending");

               int rowCount =  pst.executeUpdate();
                if (rowCount > 0) {
                    isReturned = true;
                }else{
                    isReturned = false;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
                return isReturned;   
}
    //updating book count
    public int updateBookCountsql(int bookId) {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "update book_details set quantity = quantity + 1 where book_id = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bookId);

            int rowCount = pst.executeUpdate();
            return rowCount;
            } 
         catch (Exception e) {
            e.printStackTrace();
        }
            return 0;

    }
}

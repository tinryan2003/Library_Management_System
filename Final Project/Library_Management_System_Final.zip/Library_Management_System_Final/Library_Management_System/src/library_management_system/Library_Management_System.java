package library_management_system;

import GUI.LoginPage;

public class Library_Management_System {

    public static void main(String[] args) {
        LoginPage Start = new LoginPage();
        Start.setVisible(true);
        Start.pack();
        Start.setLocationRelativeTo(null); 
    }
    
}

package Controller;

abstract class LMS {
    public int id;
    public String name;
    public String username;
    public String pwd;
    
    public LMS( String username, String pwd, int id, String name){
        this.username = username;
        this.id = id;
        this.pwd = pwd;
        this.name = name;
    }
    
    public LMS(int id){
        this.id = id;
    }
    
    public LMS(int id, String name){
        this.username="";
        this.pwd = "";
        this.id = id;
        this.name = name;
}
}

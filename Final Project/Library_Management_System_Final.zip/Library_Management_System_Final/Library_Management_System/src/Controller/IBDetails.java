package Controller;

import java.util.Date;

public class IBDetails {
    private Date issueDate, dueDate;
    private int issueId;
    private String bookName; 
    private  String studentName;

    public IBDetails(int issueId, String bookName, String studentName, Date issueDate, Date dueDate) {
        this.issueId = issueId;
        this.bookName = bookName;
        this.studentName = studentName;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
    }
    public IBDetails() {}
    
    public IBDetails getIssueBookDetailscontrol(int bookId, int studentId) {
        Database.IBD_SQL ibsql = new Database.IBD_SQL();
        IBDetails bookDetails = ibsql.getIssueBookDetailssql(bookId,studentId);
        return bookDetails;       
    }
    
    
    // Getter method for issueDate
    public Date getIssueDate() {
        return issueDate;
    }

    // Getter method for dueDate
    public Date getDueDate() {
        return dueDate;
    }

    // Getter method for issueId
    public int getIssueId() {
        return issueId;
    }

    // Getter method for bookName
    public String getBookName() {
        return bookName;
    }

    // Getter method for studentName
    public String getStudentName() {
        return studentName;
    }   
 }

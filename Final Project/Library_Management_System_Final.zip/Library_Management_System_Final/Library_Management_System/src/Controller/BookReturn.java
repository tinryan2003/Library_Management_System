 
package Controller;

    public class BookReturn extends Book{

        //return the book 
        public boolean returnBook(int studentId, int bookId){
            Database.RB_SQL rbsql = new Database.RB_SQL();
            return rbsql.returnBooksql(studentId, bookId);

    }
    
    //updating book count
    public int updateBookCountcontrol(int bookId) {
        Database.RB_SQL rbsql = new Database.RB_SQL();
        return rbsql.updateBookCountsql(bookId);
    }
    
}      
    



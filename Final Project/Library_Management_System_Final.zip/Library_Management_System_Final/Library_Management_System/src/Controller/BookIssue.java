package Controller;

import java.util.Date;

public class BookIssue extends Book {
    private Book b;
    private Student s;
    
    public BookIssue(String n, String a, int i, int q) {
        b = new Book(n, a, i, q);
    }

    public BookIssue(int i, String n, String c, String b) {
        s = new Student(i, n, c, b);
    }
    
    public BookIssue(){}
 
    public BookIssue getBookDetailscontrol(int bookId) {
        Database.IB_SQL ibsql = new Database.IB_SQL();
        BookIssue bookDetails = ibsql.getBookDetailssql(bookId);
        return bookDetails;
    }
    
    public BookIssue getStudentDetailscontrol(int studentId) {
        Database.IB_SQL ibsql = new Database.IB_SQL();
        BookIssue studentDetails = ibsql.getStudentDetailssql(studentId);
        return studentDetails;
    }
    
    //checking whether book already allocated or not
    public boolean isAlreadyIssuedcontrol(int bookId, int studentId) {
        Database.IB_SQL ibsql = new Database.IB_SQL();
        return ibsql.isAlreadyIssuedsql(bookId,studentId);
    }
    
    //insert issue book details to database
    public boolean issueBookcontrol(int bookId, int studentId, String bookName, String studentName, Date uIssueDate, Date uDueDate, long l1, long l2 ) {
        Database.IB_SQL ibsql = new Database.IB_SQL();
        return ibsql.issueBooksql(bookId, studentId, bookName, studentName, uIssueDate, uDueDate, l1, l2);

    }
    
    //updating book count
    public int updateBookCountcontrol(int bookId) {
        Database.IB_SQL ibsql  = new Database.IB_SQL();
        return ibsql.updateBookCountsql(bookId);
    }
    

    @Override
    public int getBookId() {
        return b.bookId;
    }

    @Override
    public String getBookName() {
        return b.bookName;
    }

    @Override
    public String getAuthor() {
        return b.author;
    }

    @Override
    public int getQuantity() {
        return b.quantity;
    }
    
    public int getId() {
        return s.id;
    }

    public String getCourse() {
        return s.course;
    }

    public String getBranch() {
        return s.branch;
    }  

    public String getName() {
       return s.name;
    }
}

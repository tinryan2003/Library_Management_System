package Controller;

/**
 *
 * @author Paul
 */
public interface BookInterface {

    // Method to add a book
    boolean addBook(int bookId, String bookName, String author, int quantity);

    // Method to update book information
    boolean updateBook(int bookId, String bookName, String author, int quantity);

    // Method to delete a book
    boolean deleteBook(int bookId);

    // Setter method for bookId
    void setBookId(int bookId);

    // Setter method for author
    void setAuthorName(String author);

    // Setter method for quantity
    void setQuantity(int quantity);

    // Setter method for bookName
    void setBookName(String bookName);

    String getBookName();

    String getAuthor();

    int getBookId();

    int getQuantity();
}

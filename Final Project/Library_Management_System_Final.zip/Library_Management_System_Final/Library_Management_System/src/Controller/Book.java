package Controller;

public class Book implements BookInterface {

    public String bookName;
    public String author;
    public int bookId;
    public int quantity;

    private Database.MB_SQL bsql = new Database.MB_SQL();

    public Book(String n, String a, int i, int q) {
        this.bookName = n;
        this.author = a;
        this.bookId = i;
        this.quantity = q;
    }

    public Book() {
        this.bookName = "";
        this.author = "";
        this.bookId = 0;
        this.quantity = 0;
    }

    public Book(int i) {
        this.bookId = i;
    }

    //to add student to student_details table
    @Override
    public boolean addBook(int i, String n, String a, int q) {
        this.bookId = i;
        this.bookName = n;
        this.author = a;
        this.quantity = q;
        return bsql.addBooksql(this);
    }

    //to update student's data
    @Override
    public boolean updateBook(int i, String n, String a, int q) {
        this.bookId = i;
        this.bookName = n;
        this.author = a;
        this.quantity = q;
        return bsql.updateBooksql(this);
    }

    //method to delete student
    @Override
    public boolean deleteBook(int i) {
        return bsql.deleteBooksql(i);
    }

    @Override
    public void setBookId(int id) {
        this.bookId = id;
    }

    @Override
    public void setAuthorName(String an) {
        this.author = an;
    }

    @Override
    public void setQuantity(int q) {
        this.quantity = q;
    }

    @Override
    public void setBookName(String bn) {
        this.bookName = bn;
    }

    @Override
    public String getBookName() {
        return bookName;
    }

    @Override
    public String getAuthor() {
        return author;
    }

    @Override
    public int getBookId() {
        return bookId;
    }

    @Override
    public int getQuantity() {
        return quantity;
    }

}

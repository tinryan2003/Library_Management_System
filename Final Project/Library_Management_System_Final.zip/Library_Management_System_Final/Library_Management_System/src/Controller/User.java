package Controller;

public class User extends LMS{
    private String email;
    private String phoneNo;
    
    Database.MU_SQL musql = new Database.MU_SQL();
    public User(){
        super("","",0,"");
        this.email = "";
        this.phoneNo = "";
    }
    
    public User(String un, String pwd, int i, String n, String e, String p){
        super(un, pwd, i, n);
        this.email = e;
        this.phoneNo = p;
    }
    
    public boolean insertSingupDetailscontrol(String username, String pwd, String email, String contact){
        return musql.insertSignupDetailssql(username, pwd, email, contact) > 0;
    }
    
    public boolean checkDuplicateUsercontrol(String username){
        return musql.checkDuplicateUser(username);
        
    } 
    
    /*verify creds
    public void login(String usernamem, String pwd) {   
    GUI.LoginPage lg = new GUI.LoginPage(); 
    Database.MU_SQL i = new Database.MU_SQL();
    if (i.loginsql(usernamem,pwd)){
                lg.login_accepted();
            } else {
                lg.login_disaccepted();
            }
        }*/ 
    }


    
    

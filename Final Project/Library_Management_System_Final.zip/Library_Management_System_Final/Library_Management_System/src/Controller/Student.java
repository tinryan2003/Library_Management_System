package Controller;

public class Student extends User implements StudentInterface{

    public String course;
    public String branch;

    private Database.MS_SQL mssql = new Database.MS_SQL();

    public Student() {
        super();
        this.course = "";
        this.branch = "";
    }

    public Student(int i, String n, String c, String b) {
        this.name = n;
        this.id = i;
        this.course = c;
        this.branch = b;
    }

    @Override
    public void setCourse(String c) {
        this.course = c;
    }

    @Override
    public void setBranch(String b) {
        this.branch = b;
    }

    //to add student to student_details table
    @Override
    public boolean addStudent(int i, String n, String c, String b) {
        this.id = i;
        this.name = n;
        this.course = c;
        this.branch = b;
        return mssql.addStudentsql(this);
    }

    //to update student's data
    @Override
    public boolean updateStudent(int i, String n, String c, String b) {
        this.id = i;
        this.name = n;
        this.course = c;
        this.branch = b;
        return mssql.updateStudentsql(this);
    }

    //method to delete student
    @Override
    public boolean deleteStudent(int id) {
        return mssql.deleteStudentsql(id);
    }

}

package Controller;

public interface StudentInterface {
    boolean addStudent(int id, String name, String course, String branch);

    // Method to update student information
    boolean updateStudent(int id, String name, String course, String branch);

    // Method to delete a student
    boolean deleteStudent(int id);
    
    // Setter method for course
    void setCourse(String course);

    // Setter method for branch
    void setBranch(String branch);
}
